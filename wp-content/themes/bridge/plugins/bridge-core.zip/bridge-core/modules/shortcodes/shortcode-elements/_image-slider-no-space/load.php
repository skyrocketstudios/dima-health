<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_image-slider-no-space/image-slider-no-space.php';
