<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_counter/counter.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_counter/custom-styles/custom-styles.php';