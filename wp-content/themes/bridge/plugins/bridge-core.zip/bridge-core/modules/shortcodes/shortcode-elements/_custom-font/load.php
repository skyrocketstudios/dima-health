<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_custom-font/custom-font.php';
