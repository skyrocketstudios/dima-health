<?php

include_once QODE_TOURS_CPT_PATH . '/tours/tours-register.php';
include_once QODE_TOURS_CPT_PATH . '/tours/helper-functions.php';
include_once QODE_TOURS_CPT_PATH . '/tours/tax-custom-fields.php';
include_once QODE_TOURS_CPT_PATH . '/tours/profile/dashboard-functions.php';
include_once QODE_TOURS_CPT_PATH . '/tours/widgets/widgets-functions.php';