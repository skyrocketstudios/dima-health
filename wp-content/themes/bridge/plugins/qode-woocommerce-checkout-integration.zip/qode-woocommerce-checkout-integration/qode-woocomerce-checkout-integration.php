<?php
/*
Plugin Name: Qode Woocommerce Checkout Integration
Description: Plugin that adds custom post type to woocommerce checkout
Author: Qode Themes
Version: 2.0
*/

include_once 'load.php';
