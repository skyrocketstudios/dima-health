<?php

include_once QODE_LMS_CPT_PATH . '/question/question-register.php';
include_once QODE_LMS_CPT_PATH . '/question/helper-functions.php';