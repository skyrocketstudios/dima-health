(function($) {
	'use strict';

	var listingGallery = {};
	qode.modules.listingGallery = listingGallery;

	listingGallery.qodeOnDocumentReady = qodeOnDocumentReady;

	$(document).ready(qodeOnDocumentReady);

	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function qodeOnDocumentReady() {

	}



})(jQuery);